package com.example.task24

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
